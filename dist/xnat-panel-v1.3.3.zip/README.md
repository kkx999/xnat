# XNAT Panel v1.3.3

XNAT 控制平面组件。v1.3.3 延续 Mobile API v1，并统一增强 Panel / Host 的 xnat 管理脚本交互，供 XNAT Android v1.0.0 使用，同时保留浏览器 Session + CSRF 流程。正式部署请使用仓库根目录的一键安装/升级脚本。
